import express from 'express'
import fs from 'fs'

const app = express()

const visitas = {
    items: 0, 
    item: 0
}

app.get('/items', (req,res) => {
    visitas.items++
    fs.readFile('productos.txt', 'utf-8', (error, productos) => {
        let prods = JSON.parse(productos)
        res.send({items: prods, cantidad: prods.length})
    })
})

app.get('/item-random', (req,res) => {
    visitas.item++
    fs.readFile('productos.txt', 'utf-8', (error, productos) => {
        let prods = JSON.parse(productos)
        let random = parseInt(Math.random()*prods.length)
        res.send({item: prods[random]})
    })
})

app.get('/visitas', (req,res) => {
    res.send({visitas})
})


const PORT = 8080

const server = app.listen(PORT, () => {
    console.log(`Servidor http escuchando en el puerto ${server.address().port}`)
})
server.on("error", error => console.log(`Error en servidor ${error}`))
